from typing import Dict, Any, List
from backend.research.search import search_duckduckgo
from backend.research.source_ranker import rank_sources
from backend.ai.gemini import GeminiProvider
from backend.config.config import config_manager

class DeepResearcher:
    def __init__(self):
        self.ai = GeminiProvider()

    def conduct_research(self, topic: str, max_sources: int = 6) -> Dict[str, Any]:
        """
        Executes multi-step deep research process:
        1. Query breakdown
        2. Web search across sources
        3. Credibility evaluation & ranking
        4. Information extraction & synthesis with markdown citations
        """
        print(f"[DeepResearcher] Conducting research on: {topic}")
        
        # Step 1: Search web
        raw_sources = search_duckduckgo(topic, max_results=max_sources * 2)
        
        # Step 2: Rank sources
        ranked = rank_sources(raw_sources)[:max_sources]

        # Step 3: Format sources text
        sources_text = ""
        citation_links = []
        for idx, src in enumerate(ranked, 1):
            sources_text += f"\nSOURCE [{idx}]: {src['title']}\nURL: {src['url']}\nSnippet: {src['snippet']}\nScore: {src['credibility_score']}\n"
            citation_links.append({"index": idx, "title": src["title"], "url": src["url"]})

        # Step 4: Synthesize summary via AI Provider
        prompt = f"""
Conduct a comprehensive deep research synthesis for Sir on the following topic:

TOPIC: "{topic}"

COLLECTED SOURCES:
{sources_text}

STRUCTURE YOUR RESPONSE IN MARKDOWN:
1. Executive Summary
2. Key Facts & Findings (cite sources using [1], [2] format)
3. In-Depth Analysis & Nuances
4. Conclusions & Uncertainties (if any)
5. List of References (Markdown clickable links)

Always address the user as "Sir".
"""
        res = self.ai.generate_response([{"role": "user", "content": prompt}])
        summary_markdown = res.get("content", "Research synthesis complete, Sir.")

        return {
            "topic": topic,
            "sources_count": len(ranked),
            "citations": citation_links,
            "summary": summary_markdown
        }

deep_researcher = DeepResearcher()
