import re
from typing import Dict, Any

BLOCKED_PATTERNS = [
    r"rm\s+-rf",
    r"del\s+/s\s+/q",
    r"format\s+[c-z]:",
    r"drop\s+database",
    r"shutdown",
    r"icacls",
]

def sanitize_tool_args(tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates and sanitizes tool arguments. Prevents injection attacks.
    """
    sanitized = {}
    for key, val in args.items():
        if isinstance(val, str):
            # Check blocked malicious commands
            for pat in BLOCKED_PATTERNS:
                if re.search(pat, val, re.IGNORECASE):
                    raise ValueError(f"Security Alert: Argument '{key}' matched blocked pattern '{pat}'")
            sanitized[key] = val.strip()
        else:
            sanitized[key] = val
    return sanitized

def redact_sensitive_info(text: str) -> str:
    """
    Redacts passwords, tokens, API keys before logging or displaying.
    """
    if not text:
        return ""
    # Redact Gemini / Generic API keys (AIza..., sk-...)
    text = re.sub(r'AIzaSy[A-Za-z0-9_-]{33}', '[REDACTED_API_KEY]', text)
    text = re.sub(r'sk-[A-Za-z0-9]{32,}', '[REDACTED_API_KEY]', text)
    return text
