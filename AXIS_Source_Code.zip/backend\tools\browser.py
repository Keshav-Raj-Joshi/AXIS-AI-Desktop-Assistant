import time
from typing import Dict, Any, List, Optional
from backend.tools.registry import tool_registry
from backend.security.permissions import PermissionLevel

# Global browser instance handle
_playwright = None
_browser = None
_context = None
_pages: List[Any] = []
_active_page_idx: int = 0

def _ensure_browser():
    global _playwright, _browser, _context, _pages, _active_page_idx
    if _browser is None or not _browser.is_connected():
        from playwright.sync_api import sync_playwright
        _playwright = sync_playwright().start()
        # Launch persistent or standard chromium browser in headed or headless mode
        _browser = _playwright.chromium.launch(
            headless=False, # Visible browser for user interaction & natural computer control
            args=["--start-maximized"]
        )
        _context = _browser.new_context(no_viewport=True)
        initial_page = _context.new_page()
        _pages = [initial_page]
        _active_page_idx = 0

def _get_active_page():
    _ensure_browser()
    global _pages, _active_page_idx
    if not _pages:
        p = _context.new_page()
        _pages.append(p)
        _active_page_idx = 0
    if _active_page_idx >= len(_pages):
        _active_page_idx = max(0, len(_pages) - 1)
    return _pages[_active_page_idx]

@tool_registry.register(
    name="open_browser",
    description="Launches or focuses the Playwright web browser window.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.SAFE
)
def open_browser() -> str:
    _ensure_browser()
    return "Web browser launched and ready, Sir."

@tool_registry.register(
    name="open_url",
    description="Navigates the browser to a specific web URL.",
    schema={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "The destination URL (e.g. https://google.com or youtube.com)."}
        },
        "required": ["url"]
    },
    permission_level=PermissionLevel.SAFE
)
def open_url(url: str) -> str:
    page = _get_active_page()
    target = url if url.startswith(("http://", "https://")) else f"https://{url}"
    page.goto(target, timeout=20000, wait_until="domcontentloaded")
    
    # Check if page requires authentication
    content_lower = page.content().lower()
    if any(k in content_lower for k in ["sign in", "log in", "2fa", "captcha", "one-time password"]):
        return f"Navigated to '{target}', Sir. Note: Authentication or CAPTCHA may be required. Please complete login directly in the open browser window if needed."

    return f"Successfully navigated to '{target}', Sir."

@tool_registry.register(
    name="new_tab",
    description="Opens a new browser tab.",
    schema={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "Optional URL to open in the new tab."}
        }
    },
    permission_level=PermissionLevel.SAFE
)
def new_tab(url: Optional[str] = None) -> str:
    _ensure_browser()
    global _pages, _active_page_idx
    p = _context.new_page()
    _pages.append(p)
    _active_page_idx = len(_pages) - 1
    
    if url:
        target = url if url.startswith(("http://", "https://")) else f"https://{url}"
        p.goto(target, timeout=20000)
        return f"Opened new tab navigating to '{target}', Sir."
    
    p.goto("https://www.google.com")
    return f"Opened new tab #{_active_page_idx + 1}, Sir."

@tool_registry.register(
    name="close_tab",
    description="Closes the active browser tab.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.MODERATE
)
def close_tab() -> str:
    global _pages, _active_page_idx
    if not _pages:
        return "No open browser tabs to close, Sir."
    
    page = _pages[_active_page_idx]
    page.close()
    _pages.pop(_active_page_idx)
    _active_page_idx = max(0, _active_page_idx - 1)
    return "Closed tab, Sir."

@tool_registry.register(
    name="switch_tab",
    description="Switches active tab focus by tab index (1-based).",
    schema={
        "type": "object",
        "properties": {
            "index": {"type": "integer", "description": "1-based index of the tab to switch to."}
        },
        "required": ["index"]
    },
    permission_level=PermissionLevel.SAFE
)
def switch_tab(index: int) -> str:
    global _pages, _active_page_idx
    if not _pages:
        return "No active browser window, Sir."
    idx = index - 1
    if 0 <= idx < len(_pages):
        _active_page_idx = idx
        _pages[_active_page_idx].bring_to_front()
        return f"Switched to tab #{index}, Sir."
    return f"Tab index {index} out of range (1..{len(_pages)}), Sir."

@tool_registry.register(
    name="browser_search",
    description="Performs a Google web search directly in the browser.",
    schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search term or question."}
        },
        "required": ["query"]
    },
    permission_level=PermissionLevel.SAFE
)
def browser_search(query: str) -> str:
    page = _get_active_page()
    encoded = query.replace(" ", "+")
    page.goto(f"https://www.google.com/search?q={encoded}", timeout=20000, wait_until="domcontentloaded")
    return f"Executed search for '{query}' in browser, Sir."

@tool_registry.register(
    name="read_page",
    description="Extracts the main readable text content and title from the active web page.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.SAFE
)
def read_page() -> Dict[str, Any]:
    page = _get_active_page()
    title = page.title()
    url = page.url
    text = page.evaluate("() => document.body ? document.body.innerText : ''")
    
    # Clean text snippet
    clean_text = "\n".join([line.strip() for line in text.split("\n") if line.strip()])[:3000]
    return {
        "title": title,
        "url": url,
        "content_snippet": clean_text
    }

@tool_registry.register(
    name="click",
    description="Clicks a CSS selector or visible text link on the active web page.",
    schema={
        "type": "object",
        "properties": {
            "selector": {"type": "string", "description": "CSS selector or exact text to click."}
        },
        "required": ["selector"]
    },
    permission_level=PermissionLevel.MODERATE
)
def click(selector: str) -> str:
    page = _get_active_page()
    try:
        page.click(selector, timeout=5000)
    except Exception:
        # Fallback click by text
        page.get_by_text(selector).first.click(timeout=5000)
    return f"Clicked on '{selector}', Sir."

@tool_registry.register(
    name="type",
    description="Types text into a form input or active selector.",
    schema={
        "type": "object",
        "properties": {
            "selector": {"type": "string", "description": "CSS selector or input field identifier."},
            "text": {"type": "string", "description": "Text to fill into field."}
        },
        "required": ["selector", "text"]
    },
    permission_level=PermissionLevel.MODERATE
)
def type(selector: str, text: str) -> str:
    page = _get_active_page()
    page.fill(selector, text, timeout=5000)
    return f"Typed content into '{selector}', Sir."

@tool_registry.register(
    name="scroll",
    description="Scrolls the active browser page down or up.",
    schema={
        "type": "object",
        "properties": {
            "direction": {"type": "string", "description": "'down' or 'up'"}
        }
    },
    permission_level=PermissionLevel.MODERATE
)
def scroll(direction: str = "down") -> str:
    page = _get_active_page()
    delta = 600 if direction.lower() == "down" else -600
    page.mouse.wheel(0, delta)
    return f"Scrolled page {direction}, Sir."
