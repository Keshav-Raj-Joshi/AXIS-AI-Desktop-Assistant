import os
import json
import asyncio
from typing import Dict, Any, List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.config.config import config_manager
from backend.diagnostics import run_system_diagnostics
from backend.agent.agent import axis_agent, AgentState
from backend.memory.memory_manager import memory_manager
from backend.tools.registry import tool_registry

# Import tool modules to trigger decorators
import backend.tools.system
import backend.tools.applications
import backend.tools.browser
import backend.tools.research

from backend.ai.gemini import GeminiProvider
from backend.voice.text_to_speech import tts_provider

app = FastAPI(title="A.X.I.S. Personal AI Desktop Assistant Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Active WebSocket connections
active_connections: List[WebSocket] = []

def broadcast_event(data: Dict[str, Any]):
    asyncio.run(broadcast_async(data))

async def broadcast_async(data: Dict[str, Any]):
    for ws in list(active_connections):
        try:
            await ws.send_json(data)
        except Exception:
            active_connections.remove(ws)

# Register listener on agent
axis_agent.add_listener(lambda evt: broadcast_event(evt))

@app.on_event("startup")
def startup_event():
    print("[A.X.I.S.] Starting backend initialization...")
    tts_provider.speak("Good day, Sir. A.X.I.S. is online.")

@app.get("/api/health")
def health_check():
    return {"status": "online", "agent_state": axis_agent.state.value}

@app.get("/api/diagnostics")
def get_diagnostics():
    return run_system_diagnostics()

@app.get("/api/settings")
def get_settings():
    return config_manager.to_dict(mask_keys=True)

class SettingsPayload(BaseModel):
    gemini_api_key: str = None
    gemini_model: str = None
    wake_word: str = None
    continuous_listening: bool = None
    privacy_mode: bool = None
    developer_mode: bool = None
    auto_confirm_moderate: bool = None
    tts_speed: int = None
    tts_volume: float = None

@app.post("/api/settings")
def update_settings(payload: SettingsPayload):
    data = {k: v for k, v in payload.dict().items() if v is not None}
    if "gemini_api_key" in data and data["gemini_api_key"]:
        os.environ["GEMINI_API_KEY"] = data["gemini_api_key"]
    config_manager.update(data)
    return {"status": "updated", "config": config_manager.to_dict(mask_keys=True)}

@app.post("/api/settings/test-gemini")
def test_gemini_connection(payload: Dict[str, str] = None):
    key = payload.get("api_key") if payload else None
    provider = GeminiProvider(api_key=key)
    success = provider.test_connection()
    return {"success": success, "message": "Connection successful, Sir!" if success else "Failed to connect to Gemini API. Please check key."}

class CommandPayload(BaseModel):
    command: str

@app.post("/api/command")
def send_command(payload: CommandPayload):
    result = axis_agent.process_command(payload.command)
    return result

@app.post("/api/stop")
def stop_command():
    axis_agent.request_stop()
    return {"status": "stopped", "message": "Task cancelled by Sir."}

# Memory Endpoints
@app.get("/api/memory")
def get_memories():
    return memory_manager.list_all()

class MemoryPayload(BaseModel):
    fact: str
    category: str = "User Preferences"

@app.post("/api/memory")
def add_memory(payload: MemoryPayload):
    return memory_manager.remember(payload.fact, payload.category)

@app.delete("/api/memory/{memory_id}")
def delete_memory(memory_id: int):
    return memory_manager.forget(memory_id=memory_id)

@app.delete("/api/memory")
def clear_all_memories():
    return memory_manager.clear_all()

# Tools Endpoints
@app.get("/api/tools")
def get_tools():
    return tool_registry.list_tools()

# WebSocket for real-time speech & agent state telemetry
@app.websocket("/ws/axis")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    print("[WebSocket] Client connected to A.X.I.S.")
    
    await websocket.send_json({
        "event": "connection_established",
        "state": axis_agent.state.value,
        "diagnostics": run_system_diagnostics()
    })

    try:
        while True:
            data = await websocket.receive_text()
            payload = json.loads(data)
            action = payload.get("action")

            if action == "command":
                cmd = payload.get("command", "")
                res = axis_agent.process_command(cmd)
                await websocket.send_json({"event": "command_result", "result": res})
            elif action == "stop":
                axis_agent.request_stop()
                await websocket.send_json({"event": "stopped"})
            elif action == "ping":
                await websocket.send_json({"event": "pong"})
    except WebSocketDisconnect:
        active_connections.remove(websocket)
        print("[WebSocket] Client disconnected.")
