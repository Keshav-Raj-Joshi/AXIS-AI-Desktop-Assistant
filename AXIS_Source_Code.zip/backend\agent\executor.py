from typing import Dict, Any, Tuple
from backend.tools.registry import tool_registry
from backend.security.permissions import permission_manager, PermissionLevel
from backend.config.config import config_manager

class ToolExecutor:
    def execute(self, tool_name: str, args: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, str]:
        """
        Validates permissions and executes tool.
        Returns: (result_dict, permission_granted, message)
        """
        tool = tool_registry.get_tool(tool_name)
        if not tool:
            return {"error": f"Tool '{tool_name}' is not registered."}, True, "Tool missing"

        auto_confirm = config_manager.get("auto_confirm_moderate", False)
        allowed, level, msg = permission_manager.check_permission(tool_name, args, auto_confirm_moderate=auto_confirm)

        if not allowed:
            return {
                "requires_confirmation": True,
                "tool_name": tool_name,
                "args": args,
                "level": level.value,
                "message": msg
            }, False, msg

        exec_res = tool.execute(**args)
        return exec_res, True, "Executed"

tool_executor = ToolExecutor()
