import os
import json
import requests
from typing import List, Dict, Any, Optional
from backend.ai.provider import AIProvider
from backend.ai.prompts import AXIS_SYSTEM_PROMPT
from backend.config.config import config_manager

class GeminiProvider(AIProvider):
    def __init__(self, api_key: Optional[str] = None, model: str = "gemini-2.5-flash"):
        self.api_key = api_key or config_manager.get("gemini_api_key", "")
        self.model = model or config_manager.get("gemini_model", "gemini-2.5-flash")

    def _get_api_key(self) -> str:
        key = self.api_key or config_manager.get("gemini_api_key", "") or os.getenv("GEMINI_API_KEY", "")
        return key

    def test_connection(self) -> bool:
        key = self._get_api_key()
        if not key:
            return False
        
        # Test request using Gemini REST API
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models?key={key}"
            res = requests.get(url, timeout=5)
            return res.status_code == 200
        except Exception as e:
            print(f"[GeminiProvider] Connection test error: {e}")
            return False

    def generate_response(
        self, 
        messages: List[Dict[str, Any]], 
        system_instruction: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        key = self._get_api_key()
        if not key:
            return {
                "content": "Sir, my Gemini API Key is not configured yet. Please enter your API Key in the Settings panel.",
                "tool_calls": [],
                "error": "API Key missing"
            }

        sys_prompt = system_instruction or AXIS_SYSTEM_PROMPT

        # Try google.genai or google.generativeai or REST API fallback
        try:
            return self._generate_via_sdk(key, messages, sys_prompt, tools)
        except Exception as e:
            print(f"[GeminiProvider] SDK generation failed ({e}), attempting REST fallback...")
            return self._generate_via_rest(key, messages, sys_prompt, tools)

    def _generate_via_sdk(self, key: str, messages: List[Dict[str, Any]], sys_prompt: str, tools: Optional[List[Dict[str, Any]]]):
        try:
            from google import genai
            from google.genai import types

            client = genai.Client(api_key=key)
            contents = []
            for m in messages:
                role = "user" if m.get("role") in ["user", "human"] else "model"
                contents.append(types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=m.get("content", ""))]
                ))

            config = types.GenerateContentConfig(
                system_instruction=sys_prompt,
                temperature=0.7
            )

            response = client.models.generate_content(
                model=self.model,
                contents=contents,
                config=config
            )

            text = response.text or ""
            return {
                "content": text,
                "tool_calls": [],
                "raw_response": response
            }
        except ImportError:
            # Try google.generativeai
            import google.generativeai as genai
            genai.configure(api_key=key)
            model_inst = genai.GenerativeModel(
                model_name=self.model,
                system_instruction=sys_prompt
            )
            
            history = []
            for m in messages[:-1]:
                role = "user" if m.get("role") in ["user", "human"] else "model"
                history.append({"role": role, "parts": [m.get("content", "")]})

            last_msg = messages[-1].get("content", "") if messages else ""
            chat = model_inst.start_chat(history=history)
            response = chat.send_message(last_msg)
            return {
                "content": response.text or "",
                "tool_calls": [],
                "raw_response": response
            }

    def _generate_via_rest(self, key: str, messages: List[Dict[str, Any]], sys_prompt: str, tools: Optional[List[Dict[str, Any]]]):
        model_name = self.model
        if not model_name.startswith("models/"):
            model_name = f"models/{model_name}"

        url = f"https://generativelanguage.googleapis.com/v1beta/{model_name}:generateContent?key={key}"
        
        contents = []
        for m in messages:
            role = "user" if m.get("role") in ["user", "human"] else "model"
            contents.append({
                "role": role,
                "parts": [{"text": m.get("content", "")}]
            })

        payload = {
            "system_instruction": {
                "parts": [{"text": sys_prompt}]
            },
            "contents": contents
        }

        res = requests.post(url, json=payload, timeout=20)
        if res.status_code == 200:
            data = res.json()
            candidates = data.get("candidates", [])
            text = ""
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                text = "".join([p.get("text", "") for p in parts])
            return {
                "content": text,
                "tool_calls": [],
                "raw_response": data
            }
        else:
            err_msg = f"Gemini API returned HTTP {res.status_code}: {res.text}"
            return {
                "content": f"Apologies, Sir. I encountered an error communicating with Gemini: {res.status_code}",
                "tool_calls": [],
                "error": err_msg
            }
