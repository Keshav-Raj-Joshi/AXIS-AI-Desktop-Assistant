import inspect
from typing import Dict, Any, Callable, List, Optional
from backend.security.permissions import permission_manager, PermissionLevel
from backend.security.validation import sanitize_tool_args

class Tool:
    def __init__(
        self,
        name: str,
        description: str,
        func: Callable,
        schema: Dict[str, Any],
        permission_level: PermissionLevel = PermissionLevel.SAFE
    ):
        self.name = name
        self.description = description
        self.func = func
        self.schema = schema
        self.permission_level = permission_level

    def execute(self, **kwargs) -> Dict[str, Any]:
        sanitized = sanitize_tool_args(self.name, kwargs)
        try:
            res = self.func(**sanitized)
            return {"status": "success", "result": res}
        except Exception as e:
            return {"status": "error", "error": str(e)}

class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, name: str, description: str, schema: Dict[str, Any], permission_level: PermissionLevel = PermissionLevel.SAFE):
        def decorator(func: Callable):
            tool = Tool(name, description, func, schema, permission_level)
            self._tools[name] = tool
            return func
        return decorator

    def get_tool(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict[str, Any]]:
        result = []
        for t in self._tools.values():
            result.append({
                "name": t.name,
                "description": t.description,
                "schema": t.schema,
                "permission_level": t.permission_level.value
            })
        return result

    def get_schemas_for_ai(self) -> List[Dict[str, Any]]:
        schemas = []
        for t in self._tools.values():
            schemas.append({
                "name": t.name,
                "description": t.description,
                "parameters": t.schema
            })
        return schemas

tool_registry = ToolRegistry()
