from enum import Enum
from typing import Dict, Any, Tuple

class PermissionLevel(str, Enum):
    SAFE = "SAFE"
    MODERATE = "MODERATE"
    SENSITIVE = "SENSITIVE"

TOOL_PERMISSIONS = {
    # Safe tools
    "get_system_info": PermissionLevel.SAFE,
    "open_application": PermissionLevel.SAFE,
    "list_applications": PermissionLevel.SAFE,
    "open_url": PermissionLevel.SAFE,
    "new_tab": PermissionLevel.SAFE,
    "switch_tab": PermissionLevel.SAFE,
    "browser_search": PermissionLevel.SAFE,
    "read_page": PermissionLevel.SAFE,
    "web_search": PermissionLevel.SAFE,
    "deep_research": PermissionLevel.SAFE,
    "remember": PermissionLevel.SAFE,
    "search_memory": PermissionLevel.SAFE,
    "list_memories": PermissionLevel.SAFE,
    "speak": PermissionLevel.SAFE,

    # Moderate tools
    "close_application": PermissionLevel.MODERATE,
    "close_tab": PermissionLevel.MODERATE,
    "forget_memory": PermissionLevel.MODERATE,
    "click": PermissionLevel.MODERATE,
    "type": PermissionLevel.MODERATE,
    "scroll": PermissionLevel.MODERATE,

    # Sensitive tools
    "execute_system_command": PermissionLevel.SENSITIVE,
    "delete_memory_vault": PermissionLevel.SENSITIVE,
    "modify_security_setting": PermissionLevel.SENSITIVE,
}

class PermissionManager:
    def __init__(self):
        self.pending_confirmations: Dict[str, Dict[str, Any]] = {}

    def get_level(self, tool_name: str) -> PermissionLevel:
        return TOOL_PERMISSIONS.get(tool_name, PermissionLevel.MODERATE)

    def check_permission(self, tool_name: str, args: Dict[str, Any], auto_confirm_moderate: bool = False) -> Tuple[bool, PermissionLevel, str]:
        level = self.get_level(tool_name)
        if level == PermissionLevel.SAFE:
            return True, level, "Action is SAFE."
        
        if level == PermissionLevel.MODERATE and auto_confirm_moderate:
            return True, level, "Action is MODERATE and auto-confirmed."

        if level in [PermissionLevel.MODERATE, PermissionLevel.SENSITIVE]:
            return False, level, f"Sir, executing tool '{tool_name}' with arguments {args} requires your explicit confirmation ({level.value})."

        return False, level, "Unknown permission level."

permission_manager = PermissionManager()
