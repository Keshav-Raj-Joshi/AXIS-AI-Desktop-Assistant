from typing import Dict, Any, List
from backend.tools.registry import tool_registry
from backend.security.permissions import PermissionLevel
from backend.research.search import search_duckduckgo
from backend.research.researcher import deep_researcher
from backend.memory.memory_manager import memory_manager

@tool_registry.register(
    name="web_search",
    description="Searches the web for facts, news, and current information.",
    schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query."}
        },
        "required": ["query"]
    },
    permission_level=PermissionLevel.SAFE
)
def web_search(query: str) -> List[Dict[str, Any]]:
    return search_duckduckgo(query)

@tool_registry.register(
    name="deep_research",
    description="Conducts a multi-source deep research pass on a topic, providing an executive report with citations.",
    schema={
        "type": "object",
        "properties": {
            "topic": {"type": "string", "description": "Topic or complex question to research."}
        },
        "required": ["topic"]
    },
    permission_level=PermissionLevel.SAFE
)
def deep_research(topic: str) -> Dict[str, Any]:
    return deep_researcher.conduct_research(topic)

@tool_registry.register(
    name="remember",
    description="Stores a fact, preference, project detail, or note in A.X.I.S. persistent memory.",
    schema={
        "type": "object",
        "properties": {
            "fact": {"type": "string", "description": "Fact or preference to remember."},
            "category": {"type": "string", "description": "Category (User Preferences, Projects, Important Facts, Tasks)."}
        },
        "required": ["fact"]
    },
    permission_level=PermissionLevel.SAFE
)
def remember(fact: str, category: str = "User Preferences") -> Dict[str, Any]:
    return memory_manager.remember(fact, category)

@tool_registry.register(
    name="forget_memory",
    description="Deletes a stored memory by memory ID or query string.",
    schema={
        "type": "object",
        "properties": {
            "memory_id": {"type": "integer", "description": "Optional ID of memory to delete."},
            "fact_query": {"type": "string", "description": "Optional search term for memory to delete."}
        }
    },
    permission_level=PermissionLevel.MODERATE
)
def forget_memory(memory_id: int = None, fact_query: str = None) -> Dict[str, Any]:
    return memory_manager.forget(memory_id, fact_query)

@tool_registry.register(
    name="search_memory",
    description="Searches persistent memory for saved facts about Sir or projects.",
    schema={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search term."}
        },
        "required": ["query"]
    },
    permission_level=PermissionLevel.SAFE
)
def search_memory(query: str) -> List[Dict[str, Any]]:
    return memory_manager.search(query)

@tool_registry.register(
    name="list_memories",
    description="Lists all stored memories in A.X.I.S. vault.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.SAFE
)
def list_memories() -> List[Dict[str, Any]]:
    return memory_manager.list_all()
