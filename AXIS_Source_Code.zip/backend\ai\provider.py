from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class AIProvider(ABC):
    """
    Abstract AI Provider interface allowing A.X.I.S. to communicate with 
    Gemini or future local/cloud LLM providers seamlessly.
    """

    @abstractmethod
    def generate_response(
        self, 
        messages: List[Dict[str, Any]], 
        system_instruction: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Generate a text response or function call structure.
        Returns dict format:
        {
            "content": str,
            "tool_calls": List[dict],  # list of {"name": tool_name, "args": {...}}
            "raw_response": Any
        }
        """
        pass

    @abstractmethod
    def test_connection(self) -> bool:
        pass
