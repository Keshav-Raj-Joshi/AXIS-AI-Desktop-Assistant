import os
import json
from pathlib import Path
from dotenv import load_dotenv

# Base Directory
BASE_DIR = Path(__file__).resolve().parent.parent.parent
ENV_FILE = BASE_DIR / ".env"
CONFIG_FILE = BASE_DIR / "backend" / "config" / "user_config.json"

# Load environment variables
load_dotenv(ENV_FILE)

DEFAULT_CONFIG = {
    "ai_provider": "gemini",
    "gemini_model": "gemini-2.5-flash",
    "gemini_api_key": "",
    "wake_word": "axis",
    "continuous_listening": True,
    "privacy_mode": False,
    "developer_mode": True,
    "tts_engine": "local",
    "tts_voice": "default",
    "tts_speed": 175,
    "tts_volume": 1.0,
    "stt_engine": "local",
    "browser_type": "chromium",
    "max_agent_iterations": 15,
    "max_research_sources": 8,
    "auto_confirm_moderate": False,
    "memory_enabled": True
}

class ConfigManager:
    def __init__(self):
        self._config = DEFAULT_CONFIG.copy()
        self.load()

    def load(self):
        # 1. Start with defaults
        self._config = DEFAULT_CONFIG.copy()

        # 2. Overlay .env API key if present
        env_key = os.getenv("GEMINI_API_KEY", "")
        if env_key:
            self._config["gemini_api_key"] = env_key

        # 3. Overlay user_config.json if present
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    user_data = json.load(f)
                    self._config.update(user_data)
            except Exception as e:
                print(f"[ConfigManager] Error reading {CONFIG_FILE}: {e}")

    def save(self):
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self._config, f, indent=2)
        except Exception as e:
            print(f"[ConfigManager] Error saving user config: {e}")

    def get(self, key, default=None):
        return self._config.get(key, default)

    def set(self, key, value):
        self._config[key] = value
        self.save()

    def update(self, data_dict: dict):
        self._config.update(data_dict)
        self.save()

    def to_dict(self, mask_keys=True):
        data = self._config.copy()
        if mask_keys and data.get("gemini_api_key"):
            key = data["gemini_api_key"]
            if len(key) > 8:
                data["gemini_api_key_masked"] = f"{key[:4]}...{key[-4:]}"
            else:
                data["gemini_api_key_masked"] = "********"
            # Don't send raw key to UI status
            data["has_gemini_key"] = True
        else:
            data["has_gemini_key"] = False
            data["gemini_api_key_masked"] = ""
        return data

config_manager = ConfigManager()
