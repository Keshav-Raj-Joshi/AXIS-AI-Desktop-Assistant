from typing import List, Dict, Any, Optional
from backend.memory.database import get_db_connection

class MemoryManager:
    def remember(self, fact: str, category: str = "User Preferences") -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if identical fact exists
        cursor.execute("SELECT id FROM memories WHERE fact = ?", (fact,))
        existing = cursor.fetchone()
        if existing:
            conn.close()
            return {"status": "exists", "id": existing["id"], "fact": fact, "category": category}

        cursor.execute(
            "INSERT INTO memories (category, fact, source) VALUES (?, ?, ?)",
            (category, fact, "user")
        )
        mem_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return {"status": "success", "id": mem_id, "fact": fact, "category": category}

    def forget(self, memory_id: Optional[int] = None, fact_query: Optional[str] = None) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()

        if memory_id:
            cursor.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        elif fact_query:
            cursor.execute("DELETE FROM memories WHERE fact LIKE ?", (f"%{fact_query}%",))
        else:
            conn.close()
            return {"status": "error", "message": "Specify memory_id or fact_query"}

        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        return {"status": "success", "deleted_count": deleted_count}

    def clear_all(self) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM memories")
        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        return {"status": "success", "deleted_count": deleted_count}

    def list_all(self) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM memories ORDER BY created_at DESC")
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def search(self, query: str) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM memories WHERE fact LIKE ? OR category LIKE ? ORDER BY created_at DESC",
            (f"%{query}%", f"%{query}%")
        )
        rows = cursor.fetchall()
        conn.close()
        return [dict(r) for r in rows]

memory_manager = MemoryManager()
