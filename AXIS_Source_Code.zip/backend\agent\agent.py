import time
import json
from enum import Enum
from typing import List, Dict, Any, Optional, Callable
from backend.ai.gemini import GeminiProvider
from backend.agent.planner import task_planner
from backend.agent.executor import tool_executor
from backend.memory.retrieval import format_memories_for_prompt
from backend.voice.text_to_speech import tts_provider
from backend.config.config import config_manager

class AgentState(str, Enum):
    IDLE = "IDLE"
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    PLANNING = "PLANNING"
    EXECUTING = "EXECUTING"
    SPEAKING = "SPEAKING"
    ERROR = "ERROR"

class AxisAgent:
    def __init__(self):
        self.state: AgentState = AgentState.IDLE
        self.ai = GeminiProvider()
        self.conversation_history: List[Dict[str, Any]] = []
        self.stop_requested: bool = False
        self.listeners: List[Callable[[Dict[str, Any]], None]] = []

    def add_listener(self, listener: Callable[[Dict[str, Any]], None]):
        self.listeners.append(listener)

    def _emit(self, event_type: str, payload: Dict[str, Any]):
        data = {
            "event": event_type,
            "state": self.state.value,
            "timestamp": time.time(),
            "payload": payload
        }
        for fn in self.listeners:
            try:
                fn(data)
            except Exception as e:
                print(f"[AxisAgent] Listener error: {e}")

    def set_state(self, new_state: AgentState):
        self.state = new_state
        self._emit("state_change", {"state": new_state.value})

    def request_stop(self):
        print("[AxisAgent] STOP command received!")
        self.stop_requested = True
        self.set_state(AgentState.IDLE)
        self._emit("task_cancelled", {"message": "Task cancelled by Sir."})
        tts_provider.speak("Task cancelled, Sir.")

    def process_command(self, user_text: str) -> Dict[str, Any]:
        self.stop_requested = False
        if not user_text:
            return {"status": "empty"}

        # Handle explicit stop voice command
        if user_text.lower().strip() in ["stop", "axis stop", "axis, stop", "cancel"]:
            self.request_stop()
            return {"status": "stopped"}

        # Check Privacy Mode
        if config_manager.get("privacy_mode", False):
            if any(w in user_text.lower() for w in ["research", "search", "google", "browser"]):
                msg = "Privacy Mode is ACTIVE, Sir. Online web research and remote connections are disabled."
                self.set_state(AgentState.SPEAKING)
                tts_provider.speak(msg)
                self.set_state(AgentState.IDLE)
                return {"status": "privacy_blocked", "response": msg}

        self.set_state(AgentState.THINKING)
        self._emit("user_message", {"content": user_text})
        
        # Add memory context to system prompt
        memories_ctx = format_memories_for_prompt()
        sys_prompt = f"Always address the user as 'Sir'.\n{memories_ctx}"

        # 1. Update history
        self.conversation_history.append({"role": "user", "content": user_text})
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-10:]

        # 2. Plan task
        self.set_state(AgentState.PLANNING)
        self._emit("timeline_step", {"step": "PLANNING", "detail": f"Analyzing intent for '{user_text}'..."})
        
        steps = task_planner.plan_task(user_text)

        execution_results = []
        if steps:
            self.set_state(AgentState.EXECUTING)
            for s in steps:
                if self.stop_requested:
                    break
                tool_name = s.get("tool_name")
                args = s.get("args", {})
                desc = s.get("description", f"Executing {tool_name}")
                
                self._emit("timeline_step", {
                    "step": "EXECUTING", 
                    "tool": tool_name, 
                    "args": args, 
                    "detail": desc
                })

                res, allowed, msg = tool_executor.execute(tool_name, args)
                execution_results.append({"step": s, "result": res, "allowed": allowed, "msg": msg})

                if not allowed:
                    # Pending permission confirmation required
                    self.set_state(AgentState.IDLE)
                    self._emit("permission_required", {
                        "tool_name": tool_name,
                        "args": args,
                        "message": msg
                    })
                    return {
                        "status": "permission_required",
                        "response": msg,
                        "tool_name": tool_name,
                        "args": args
                    }

        # 3. Final response synthesis
        self.set_state(AgentState.THINKING)
        synth_prompt = f"The user asked: '{user_text}'. Tool execution results: {json.dumps(execution_results)}. Synthesize a clear response for Sir."
        
        res = self.ai.generate_response(
            self.conversation_history + [{"role": "user", "content": synth_prompt}],
            system_instruction=sys_prompt
        )

        response_text = res.get("content", "Task completed, Sir.")
        self.conversation_history.append({"role": "model", "content": response_text})

        # 4. Speak response
        self.set_state(AgentState.SPEAKING)
        self._emit("agent_response", {"content": response_text, "tools_used": execution_results})
        tts_provider.speak(response_text)

        self.set_state(AgentState.IDLE)
        return {
            "status": "success",
            "response": response_text,
            "tools_used": execution_results
        }

axis_agent = AxisAgent()
