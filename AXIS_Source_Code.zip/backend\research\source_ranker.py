from typing import List, Dict, Any

HIGH_CREDIBILITY_DOMAINS = [
    ".gov", ".edu", ".org", "wikipedia.org", "github.com", "arxiv.org",
    "nature.com", "sciencedirect.com", "python.org", "developer.mozilla.org",
    "microsoft.com", "google.com", "reuters.com", "bbc.com", "mit.edu"
]

def rank_sources(sources: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Ranks sources based on domain authority, official vs academic status, and snippet relevance.
    """
    for s in sources:
        score = 5.0
        url = s.get("url", "").lower()
        
        for dom in HIGH_CREDIBILITY_DOMAINS:
            if dom in url:
                score += 3.0
                break

        if url.startswith("https"):
            score += 1.0

        if len(s.get("snippet", "")) > 50:
            score += 1.0

        s["credibility_score"] = round(score, 1)

    return sorted(sources, key=lambda x: x.get("credibility_score", 0), reverse=True)
