import sys
import threading
from typing import Optional
from backend.config.config import config_manager

_engine = None

def _get_engine():
    global _engine
    if _engine is None:
        try:
            import pyttsx3
            _engine = pyttsx3.init()
            # Set rate and volume
            speed = config_manager.get("tts_speed", 175)
            volume = config_manager.get("tts_volume", 1.0)
            _engine.setProperty('rate', speed)
            _engine.setProperty('volume', volume)
        except Exception as e:
            print(f"[TTS] pyttsx3 init error: {e}")
            _engine = None
    return _engine

class TTSProvider:
    def __init__(self):
        pass

    def speak(self, text: str, sync: bool = False):
        if not text:
            return

        def _run_speak():
            try:
                eng = _get_engine()
                if eng:
                    eng.say(text)
                    eng.runAndWait()
            except Exception as e:
                print(f"[TTS] Speech error: {e}")

        if sync:
            _run_speak()
        else:
            t = threading.Thread(target=_run_speak, daemon=True)
            t.start()

tts_provider = TTSProvider()
