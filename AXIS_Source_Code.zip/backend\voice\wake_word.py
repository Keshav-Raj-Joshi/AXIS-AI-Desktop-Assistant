import time
import threading
from typing import Callable, Optional
from backend.config.config import config_manager

class WakeWordDetector:
    def __init__(self, callback: Optional[Callable] = None):
        self.callback = callback
        self.is_running = False
        self.wake_word = config_manager.get("wake_word", "axis").lower()

    def start_listening(self):
        if self.is_running:
            return
        self.is_running = True
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def stop_listening(self):
        self.is_running = False

    def check_text_for_wake_word(self, text: str) -> bool:
        if not text:
            return False
        clean = text.lower().strip()
        return self.wake_word in clean or "axis" in clean

    def _loop(self):
        from backend.voice.speech_to_text import stt_provider
        while self.is_running:
            if not config_manager.get("continuous_listening", True):
                time.sleep(1)
                continue
            
            try:
                recognized = stt_provider.listen_local(timeout=3)
                if recognized and self.check_text_for_wake_word(recognized):
                    print(f"[WakeWord] Wake word detected: '{recognized}'")
                    if self.callback:
                        self.callback(recognized)
            except Exception:
                pass
            time.sleep(0.5)

wake_word_detector = WakeWordDetector()
