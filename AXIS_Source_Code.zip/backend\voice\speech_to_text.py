import time
from typing import Optional

class STTProvider:
    def __init__(self):
        self.engine = "browser_or_local"

    def listen_local(self, timeout: int = 5) -> Optional[str]:
        try:
            import speech_recognition as sr
            r = sr.Recognizer()
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=0.5)
                print("[STT] Listening for audio input...")
                audio = r.listen(source, timeout=timeout, phrase_time_limit=10)
                text = r.recognize_google(audio)
                return text
        except Exception as e:
            print(f"[STT] Local speech recognition info: {e}")
            return None

stt_provider = STTProvider()
