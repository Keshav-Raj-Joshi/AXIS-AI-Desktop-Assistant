import sys
import platform
import psutil
from typing import Dict, Any
from backend.tools.registry import tool_registry
from backend.security.permissions import PermissionLevel

@tool_registry.register(
    name="get_system_info",
    description="Returns detailed OS, CPU, RAM, and system diagnostics.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.SAFE
)
def get_system_info() -> Dict[str, Any]:
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    return {
        "os": platform.system(),
        "os_release": platform.release(),
        "os_version": platform.version(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "cpu_count_logical": psutil.cpu_count(logical=True),
        "cpu_count_physical": psutil.cpu_count(logical=False),
        "cpu_usage_percent": psutil.cpu_percent(interval=0.5),
        "ram_total_gb": round(memory.total / (1024**3), 2),
        "ram_available_gb": round(memory.available / (1024**3), 2),
        "ram_used_percent": memory.percent,
        "disk_total_gb": round(disk.total / (1024**3), 2),
        "disk_free_gb": round(disk.free / (1024**3), 2),
        "python_version": sys.version.split()[0]
    }
