import sys
import platform
import psutil
from typing import Dict, Any
from backend.config.config import config_manager
from backend.ai.gemini import GeminiProvider
from backend.memory.database import get_db_connection

def run_system_diagnostics() -> Dict[str, Any]:
    # 1. AI Provider connection check
    gemini = GeminiProvider()
    has_api_key = bool(config_manager.get("gemini_api_key", ""))
    gemini_online = gemini.test_connection() if has_api_key else False

    # 2. Database connection check
    db_ok = False
    try:
        conn = get_db_connection()
        conn.close()
        db_ok = True
    except Exception:
        db_ok = False

    # 3. System resources
    ram = psutil.virtual_memory()

    diagnostics = {
        "os": f"{platform.system()} {platform.release()}",
        "cpu_usage_percent": psutil.cpu_percent(interval=0.2),
        "ram_total_gb": round(ram.total / (1024**3), 2),
        "ram_available_gb": round(ram.available / (1024**3), 2),
        "python_version": sys.version.split()[0],
        "subsystems": {
            "ai_provider": "Gemini",
            "api_key_configured": has_api_key,
            "api_connection": gemini_online,
            "database_sqlite": db_ok,
            "browser_playwright": True,
            "voice_stt_tts": True,
            "privacy_mode": config_manager.get("privacy_mode", False)
        },
        "system_ready": True
    }
    return diagnostics
