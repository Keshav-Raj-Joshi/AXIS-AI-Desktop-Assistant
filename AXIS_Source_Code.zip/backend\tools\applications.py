import os
import sys
import subprocess
import psutil
from typing import List, Dict, Any
from backend.tools.registry import tool_registry
from backend.security.permissions import PermissionLevel

COMMON_APP_MAP = {
    "chrome": ["chrome.exe", "google-chrome", "chrome"],
    "browser": ["chrome.exe", "msedge.exe", "firefox.exe", "google-chrome"],
    "edge": ["msedge.exe", "microsoft-edge"],
    "firefox": ["firefox.exe", "firefox"],
    "notepad": ["notepad.exe", "gedit"],
    "vscode": ["code.cmd", "code.exe", "code"],
    "code": ["code.cmd", "code.exe", "code"],
    "calculator": ["calc.exe", "gnome-calculator"],
    "explorer": ["explorer.exe", "nautilus"],
    "spotify": ["spotify.exe", "spotify"],
    "terminal": ["cmd.exe", "powershell.exe", "wt.exe", "gnome-terminal"]
}

@tool_registry.register(
    name="open_application",
    description="Opens a desktop application by name (e.g. Chrome, Notepad, VS Code, Calculator).",
    schema={
        "type": "object",
        "properties": {
            "app_name": {"type": "string", "description": "Name or keyword of the application to open."}
        },
        "required": ["app_name"]
    },
    permission_level=PermissionLevel.SAFE
)
def open_application(app_name: str) -> str:
    key = app_name.lower().strip()
    executables = COMMON_APP_MAP.get(key, [app_name])

    is_windows = sys.platform == "win32"

    for exe in executables:
        try:
            if is_windows:
                # Use start command to open via shell path or standard executable
                subprocess.Popen(f'start "" "{exe}"', shell=True)
            else:
                subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Successfully requested to open application '{app_name}', Sir."
        except Exception:
            continue

    # Direct fallback on windows
    if is_windows:
        try:
            os.startfile(app_name)
            return f"Opened '{app_name}' via Windows shell, Sir."
        except Exception as e:
            pass

    return f"Could not find or open application '{app_name}'. Please ensure it is installed and in PATH, Sir."

@tool_registry.register(
    name="close_application",
    description="Closes running instances of an application by process name.",
    schema={
        "type": "object",
        "properties": {
            "app_name": {"type": "string", "description": "Name of the process or application to close."}
        },
        "required": ["app_name"]
    },
    permission_level=PermissionLevel.MODERATE
)
def close_application(app_name: str) -> str:
    key = app_name.lower().strip()
    target_names = COMMON_APP_MAP.get(key, [app_name])
    closed_count = 0

    for proc in psutil.process_iter(['pid', 'name']):
        try:
            pname = proc.info['name'].lower()
            if any(t in pname for t in target_names) or key in pname:
                proc.terminate()
                closed_count += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if closed_count > 0:
        return f"Successfully closed {closed_count} instance(s) of '{app_name}', Sir."
    return f"No running application matching '{app_name}' was found, Sir."

@tool_registry.register(
    name="list_running_applications",
    description="Returns a list of currently active user applications.",
    schema={"type": "object", "properties": {}},
    permission_level=PermissionLevel.SAFE
)
def list_running_applications() -> List[str]:
    apps = set()
    for proc in psutil.process_iter(['name', 'status']):
        try:
            if proc.info['status'] == psutil.STATUS_RUNNING:
                name = proc.info['name']
                if name.endswith(('.exe', '.app')) or not '.' in name:
                    apps.add(name)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    
    sorted_apps = sorted(list(apps))[:35]
    return sorted_apps
