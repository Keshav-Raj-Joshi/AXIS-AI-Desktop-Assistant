import json
from typing import List, Dict, Any
from backend.ai.gemini import GeminiProvider
from backend.tools.registry import tool_registry

class TaskPlanner:
    def __init__(self):
        self.ai = GeminiProvider()

    def plan_task(self, user_goal: str) -> List[Dict[str, Any]]:
        tools_schema = tool_registry.get_schemas_for_ai()
        prompt = f"""
Break down the following request into a sequence of tool calls if required, or a direct response plan.

USER REQUEST: "{user_goal}"

AVAILABLE TOOLS:
{json.dumps(tools_schema, indent=2)}

Respond strictly in JSON array format:
[
  {{
    "step": 1,
    "description": "Short step explanation",
    "tool_name": "tool_name_here",
    "args": {{ ... }}
  }}
]
If no tools are required, return an empty array [].
"""
        res = self.ai.generate_response([{"role": "user", "content": prompt}])
        text = res.get("content", "").strip()
        
        # Parse JSON array
        try:
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0].strip()
            elif "```" in text:
                text = text.split("```")[1].split("```")[0].strip()

            steps = json.loads(text)
            if isinstance(steps, list):
                return steps
        except Exception as e:
            print(f"[TaskPlanner] Error parsing plan JSON: {e}")

        return []

task_planner = TaskPlanner()
