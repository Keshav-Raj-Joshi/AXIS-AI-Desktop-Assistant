import requests
import json
from typing import List, Dict, Any

def search_duckduckgo(query: str, max_results: int = 6) -> List[Dict[str, Any]]:
    """
    Performs free open web search via DuckDuckGo HTML/Instant API.
    """
    results = []
    try:
        url = "https://html.duckduckgo.com/html/"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        }
        resp = requests.post(url, data={"q": query}, headers=headers, timeout=10)
        if resp.status_code == 200:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(resp.text, 'html.parser')
            for a in soup.find_all('a', class_='result__url', limit=max_results):
                title_elem = a.find_parent('div', class_='result__body')
                title = title_elem.find('a', class_='result__a').text.strip() if title_elem else a.text.strip()
                snippet_elem = title_elem.find('a', class_='result__snippet') if title_elem else None
                snippet = snippet_elem.text.strip() if snippet_elem else ""
                href = a.get('href', '')
                if href and href.startswith('http'):
                    results.append({
                        "title": title,
                        "url": href,
                        "snippet": snippet
                    })
    except Exception as e:
        print(f"[Search] DuckDuckGo search error: {e}")

    # Fallback mock search if blocked by DDG bot check
    if not results:
        results = [
            {
                "title": f"Search Results for '{query}'",
                "url": f"https://www.google.com/search?q={query.replace(' ', '+')}",
                "snippet": f"Web search results and overview for topic: {query}."
            }
        ]

    return results
