from typing import List, Dict, Any
from backend.memory.memory_manager import memory_manager

def format_memories_for_prompt() -> str:
    """
    Formats persistent memories into a prompt context string for the AI brain.
    """
    memories = memory_manager.list_all()
    if not memories:
        return ""

    lines = ["SAVED USER MEMORIES & FACTS:"]
    for m in memories:
        lines.append(f"- [{m['category']}] {m['fact']} (ID: {m['id']})")
    
    return "\n".join(lines)
